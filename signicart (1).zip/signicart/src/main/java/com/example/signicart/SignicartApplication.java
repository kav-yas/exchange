package com.example.signicart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignicartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignicartApplication.class, args);
	}

}
